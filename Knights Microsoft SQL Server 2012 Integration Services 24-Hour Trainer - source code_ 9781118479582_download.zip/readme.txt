This zip contains accompanying solution files, queries, and other support files for 
those lessons that have them in this book, as indicated in the text. 

Not all lessons in this book have supporting files. Those that don't have any supporting files are as follows:

Lesson 2
Lesson 3
Lesson 5
Lesson 52
Lesson 54
Lesson 55
Lesson 56
Lesson 57
Lesson 59
Appendix A
Appendix B
Appendix C

We hope you enjoy the supporting materials included and that they enhance your experience with both the book and the DVD.