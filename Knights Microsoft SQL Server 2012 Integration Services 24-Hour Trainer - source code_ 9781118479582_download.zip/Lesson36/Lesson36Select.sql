/****** Select Script for Lesson 36  ******/
USE AdventureWorks2012
GO
SELECT * FROM [Production].[Lesson36ProductCategorySource]
SELECT * FROM [Production].[Lesson36ProductCategoryDestination]
GO