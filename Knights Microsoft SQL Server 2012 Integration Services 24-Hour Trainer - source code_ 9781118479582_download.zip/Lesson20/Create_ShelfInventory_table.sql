CREATE TABLE [ShelfInventory] (
    [Shelf] varchar(255),
    [ProductID] int,
    [LocationID] int,
    [Bin] int,
    [PhysicalCount] int
)
