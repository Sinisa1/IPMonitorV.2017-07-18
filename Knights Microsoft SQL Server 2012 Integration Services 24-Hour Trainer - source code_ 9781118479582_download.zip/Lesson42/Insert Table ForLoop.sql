INSERT INTO ForLoop
           (Name)
Select Distinct
LastName
From Person.Person
