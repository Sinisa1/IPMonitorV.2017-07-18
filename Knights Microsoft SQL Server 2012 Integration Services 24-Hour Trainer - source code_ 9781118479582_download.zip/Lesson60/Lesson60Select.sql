/****** Select Script for Lesson 60  ******/
USE AdventureWorks2012
GO
SELECT * FROM AdventureWorks2012.Production.Lesson60ProductSource
SELECT * FROM AdventureWorksDW2012.dbo.Lesson60DimProduct

GO