To work with the examples in this book, you�ll want to have the AdventureWorks2012 and 
AdventureWorksDW2012 databases installed. You can find the versions of these databases we 
used for this book here on the Wrox website at the following URL: 

www.wrox.com/go/SQLSever2012DataSets  

Lesson 3 of the book covers installing the sample databases. 