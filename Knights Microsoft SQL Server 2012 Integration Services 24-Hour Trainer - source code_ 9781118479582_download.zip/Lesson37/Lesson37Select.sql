/****** Select Script for Lesson 37  ******/
USE AdventureWorks2012
GO
SELECT * FROM [Production].[Lesson37ProductCategorySource]
SELECT * FROM [Production].[Lesson37ProductCategoryDestination]
GO